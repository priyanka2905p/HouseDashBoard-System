let modules = {
  room: { on: false, seconds: 0, interval: null, watt: 200 },
  borewell: { on: false, seconds: 0, interval: null, watt: 750 },
  hall: { on: false, seconds: 0, interval: null, watt: 150 }
};

function toggle(name, watt) {

  let module = modules[name];
  module.on = !module.on;

  let btn = document.getElementById(name + "Btn");

  if (module.on) {
    btn.innerText = "Switch OFF";
    btn.className = "on";

    module.interval = setInterval(() => {
      module.seconds++;

      document.getElementById(name + "Time").innerText = module.seconds;

      let energy = (module.watt * module.seconds / 3600).toFixed(2);
      document.getElementById(name + "Energy").innerText = energy;

      updateTotal();

    }, 5000);

  } else {
    btn.innerText = "Switch ON";
    btn.className = "off";
    clearInterval(module.interval);
  }
}

function updateTotal() {
  let total = 0;

  for (let key in modules) {
    let m = modules[key];
    total += (m.watt * m.seconds / 3600);
  }

  document.getElementById("totalEnergy").innerText = total.toFixed(2);
}

